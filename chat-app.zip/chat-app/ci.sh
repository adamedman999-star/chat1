#!/bin/bash
set -e
cd "$(dirname "$0")"
npm install
npx cap add android
npx cap sync android

RES=android/app/src/main/res
MAN=android/app/src/main/AndroidManifest.xml

# разрешение на уведомления
grep -q POST_NOTIFICATIONS $MAN || sed -i 's|<application|<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>\n    <application|' $MAN

# иконка приложения
rm -f $RES/mipmap-*/ic_launcher*.webp
for d in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
  mkdir -p $RES/mipmap-$d
  cp icon/$d/*.png $RES/mipmap-$d/
done
mkdir -p $RES/mipmap-anydpi-v26 $RES/values
cp icon/ic_launcher.xml icon/ic_launcher_round.xml $RES/mipmap-anydpi-v26/
cp icon/fc_icon_colors.xml $RES/values/

# постоянный ключ подписи (чтобы обновления ставились поверх)
mkdir -p ~/.android
cp debug.keystore ~/.android/debug.keystore

cd android
chmod +x gradlew
./gradlew assembleDebug
